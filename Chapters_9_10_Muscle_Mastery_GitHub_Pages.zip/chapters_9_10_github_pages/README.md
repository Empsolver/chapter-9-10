# Muscle Mastery - Chapters 9 & 10

This folder is ready for GitHub Pages.

## Publish
1. Create a new GitHub repository.
2. Upload every file and folder from this package to the repository root.
3. In GitHub, open **Settings > Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the **main** branch and **/(root)** folder, then Save.
6. GitHub will show the public study-site link after deployment.

The app is fully static: no Netlify account, server, API key, or paid hosting is required.

Browser progress is stored locally on each device/browser.
